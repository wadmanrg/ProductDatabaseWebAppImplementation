-- Table: public.products

-- DROP TABLE public.products;
drop table if exists products;

CREATE TABLE public.products
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    title character varying(50) COLLATE pg_catalog."default",
    description character varying(300) COLLATE pg_catalog."default",
    price money,
    quantity integer,
    image character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT products_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE public.products
    OWNER to postgres;