package examples.ProductDatabase.model;

public class Product {

	private int id;
	private String title;			
	private String description;
	private double price;
	private int quantity;
	private String image;
	

	// Constructor used when no date is specified
	public Product(String title, String description, double price, String image, int quantity) {
		this.title = title;
		this.description = description;
		this.price = price;
		this.image = image;
		this.quantity = quantity;
	}
	
	// Default constructor
	public Product() {
		this.title = null;
		this.description = null;
		this.price = 0.00;
		this.image = null;
		this.quantity = 0;
	}
	
	
	
	public String toString() {
		return String.format("%s\t%s\t%s\t%.2f\t%d", title, description, price, quantity);
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String img) {
		this.image = img;
	}

	public int getId() {
		return id;
	}

	public void setQuantity(String param) {
		int quantity = Integer.parseInt(param);
		setQuantity(quantity);		
	}
	
}
