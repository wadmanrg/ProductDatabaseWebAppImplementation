package examples.ProductDatabase.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.ProductDatabase.dao.ProductDAO;
import examples.ProductDatabase.model.Product;
import examples.ProductDatabase.utilities.DAOUtilities;

@WebServlet("/ProductSearch")
public class SearchResultsServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {

				String title = req.getParameter("title");
				String sorter = req.getParameter("sorter");
				List<Product> prodList;
				ProductDAO dao = DAOUtilities.getProductDAO();
				
				if(sorter != null) {
					prodList = dao.getProductsByTitle(title, sorter);
				} else {
					prodList = dao.getProductsByTitle(title);
				}
				
				// Populate the list into a variable that will be stored in the session
				req.getSession().setAttribute("products", prodList);
				req.getRequestDispatcher("SearchResults.jsp").forward(req, res);
				
	}

}