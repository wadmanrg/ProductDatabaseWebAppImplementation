package examples.ProductDatabase.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.ProductDatabase.dao.ProductDAO;
import examples.ProductDatabase.model.Product;
import examples.ProductDatabase.utilities.DAOUtilities;

/**
 * Servlet implementation class UpdateProductServlet
 */
@WebServlet("/UpdateProduct")
public class UpdateProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
		req.getRequestDispatcher("SearchDatabase.jsp").forward(req, res);
	}
       
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		boolean isSuccess= false;
		String title = req.getParameter("title");
		
		ProductDAO dao = DAOUtilities.getProductDAO();
		Product prod = dao.getProductByTitle(title);
		if(prod != null){
			// The only fields we want to be updatable are title, author and price. A new ISBN has to be applied for
			// And a new edition of a book needs to be re-published.
			prod.setTitle(req.getParameter("title"));
			prod.setDescription(req.getParameter("description"));
			prod.setPrice(Double.parseDouble(req.getParameter("price")));
			req.setAttribute("product", prod);
			isSuccess = dao.updateProduct(prod);
		}else {
			//ASSERT: couldn't find book with isbn. Update failed.
			isSuccess = false;
		}
		
		if(isSuccess){
			req.getSession().setAttribute("message", "Book successfully updated");
			req.getSession().setAttribute("messageClass", "alert-success");
			res.sendRedirect("ViewProductDetails?title=" + title);
		}else {
			req.getSession().setAttribute("message", "There was a problem updating this book...");
			req.getSession().setAttribute("messageClass", "alert-danger");
			req.getRequestDispatcher("productDetails.jsp").forward(req, res);
		}
	}

}
