package examples.ProductDatabase.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.ProductDatabase.dao.ProductDAO;
import examples.ProductDatabase.model.Product;
import examples.ProductDatabase.utilities.DAOUtilities;

/*
 * This servlet will take you to the homepage for the product module (level 100)
 */
@WebServlet("/ProductDatabase")
public class ProductServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		String sorter = req.getParameter("sorter");
		List<Product> prodList;

		// Grab the list of Products from the Database
		ProductDAO dao = DAOUtilities.getProductDAO();
		if(sorter != null) {
			prodList = dao.getAllProducts(sorter);
		} else {
			prodList = dao.getAllProducts();
		}

		 

		// Populate the list into a variable that will be stored in the session
		req.getSession().setAttribute("products", prodList);
		
				
		req.getRequestDispatcher("productHome.jsp").forward(req, res);
	}
}
