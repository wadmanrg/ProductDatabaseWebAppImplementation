package examples.ProductDatabase.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.ProductDatabase.dao.ProductDAO;
import examples.ProductDatabase.model.Product;
import examples.ProductDatabase.utilities.DAOUtilities;

public class AddProductServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("AddProduct.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		ProductDAO database = DAOUtilities.getProductDAO();
		
		Product prod = new Product();
		prod.setTitle(req.getParameter("title"));
		prod.setDescription(req.getParameter("description"));
		prod.setPrice(Double.parseDouble(req.getParameter("price")));
		prod.setPrice(Integer.parseInt(req.getParameter("quantity")));

		boolean isSuccess = database.addProduct(prod);
		
		if(isSuccess){
			req.getSession().setAttribute("message", "Product successfully published");
			req.getSession().setAttribute("messageClass", "alert-success");

			// We use a redirect here instead of a forward, because we don't
			// want request data to be saved. Otherwise, when
			// a user clicks "refresh", their browser would send the data
			// again!
			// This would be bad data management, and it
			// could result in duplicate rows in a database.
			resp.sendRedirect(req.getContextPath() + "/ProductDatabase");
		}else {
			req.getSession().setAttribute("message", "There was a problem adding the product");
			req.getSession().setAttribute("messageClass", "alert-danger");
			req.getRequestDispatcher("AddProduct.jsp").forward(req, resp);
			
		}
		
	}

}
