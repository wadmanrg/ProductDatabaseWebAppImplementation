package examples.ProductDatabase.dao;

import java.util.List;
import examples.ProductDatabase.model.Product;

/**
 * Interface for our Data Access Object to handle database queries related to Products.
 */
public interface ProductDAO {

	public List<Product> getAllProducts();
	public List<Product> getAllProducts(String sorter);
	public List<Product> getProductsByTitle(String title);
	public List<Product> getProductsByTitle(String title, String sorter);
	List<Product> getProductsByDescription(String description);
	List<Product> getProductsByDescription(String description, String sorter);
	public List<Product> getProductsLessThanPrice(double price);
	public List<Product> getProductsLessThanPrice(double price, String sorter);
	public Product getProductByTitle(String title);
	
	public boolean updateProduct(Product prod);
	public boolean deleteProductByTitle(String title);
	boolean addProduct(Product prod);
	

}
