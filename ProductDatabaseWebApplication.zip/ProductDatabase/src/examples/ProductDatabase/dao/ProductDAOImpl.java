package examples.ProductDatabase.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import examples.ProductDatabase.model.Product;
import examples.ProductDatabase.utilities.DAOUtilities;

/**
 * Implementation for the BookDAO, responsible for querying the database for Book objects.
 */
public class ProductDAOImpl implements ProductDAO {

	Connection connection = null;	// Our connection to the database
	PreparedStatement stmt = null;	// We use prepared statements to help protect against SQL injection

	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public List<Product> getAllProducts() {
		
		List<Product> products = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();	// Get our database connection from the manager
			String sql = "SELECT * FROM Products";			// Our SQL query
			
			stmt = connection.prepareStatement(sql);// Creates the prepared statement from the query
			
			ResultSet rs = stmt.executeQuery();			// Queries the database

			// So long as the ResultSet actually contains results...
			while (rs.next()) {
				// We need to populate a Book object with info for each row from our query result
				Product prod = new Product();

				// Each variable in our Book object maps to a column in a row from our results.
				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				
				prod.setImage(rs.getString("image"));
				
				// Finally we add it to the list of Book objects returned by this query.
				products.add(prod);
				
			}
			
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// We need to make sure our statements and connections are closed, 
			// or else we could wind up with a memory leak
			closeResources();
		}
		
		// return the list of Book objects populated by the DB.
		return products;
	}
/*-----------------------------------------------------------------------------------------------*/
		
		@Override
		public List<Product> getAllProducts(String sorter) {
			
			//sorter is the field to sort by
			
			List<Product> products = new ArrayList<>();

			try {
				connection = DAOUtilities.getConnection();	// Get our database connection from the manager
				String sql = "SELECT * FROM Products ORDER BY ?";			// Our SQL query
				stmt = connection.prepareStatement(sql);// Creates the prepared statement from the query
				
				stmt.setString(1, sorter);
				
				ResultSet rs = stmt.executeQuery();			// Queries the database

				// So long as the ResultSet actually contains results...
				while (rs.next()) {
					// We need to populate a Book object with info for each row from our query result
					Product prod = new Product();

					// Each variable in our Book object maps to a column in a row from our results.
					prod.setTitle(rs.getString("title"));
					prod.setDescription(rs.getString("description"));
					prod.setPrice(rs.getDouble("price"));
					
					prod.setImage(rs.getString("image"));

					
					// Finally we add it to the list of Book objects returned by this query.
					products.add(prod);
					
				}
				
				rs.close();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				// We need to make sure our statements and connections are closed, 
				// or else we could wind up with a memory leak
				closeResources();
			}
			
			// return the list of Book objects populated by the DB.
			return products;
		}
	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public List<Product> getProductsByTitle(String title) {
		
		List<Product> products = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT * FROM Products WHERE title LIKE ?";	// Note the ? in the query
			stmt = connection.prepareStatement(sql);
			
			// This command populate the 1st '?' with the title and wildcards, between ' '
			stmt.setString(1, "%" + title + "%");	
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product prod = new Product();

				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				prod.setImage(rs.getString("image"));
				
				products.add(prod);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		
		return products;
	}
	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public List<Product> getProductsByTitle(String title, String sorter) {
		
		//sorter is the field to sort by
		
		List<Product> products = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT * FROM Products WHERE title LIKE ? ORDER BY ?";	// Note the ? in the query
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, "%" + title + "%");// This command populate the 1st '?' with the title and wildcards, between ' '
			stmt.setString(2, sorter);// sets the field to sort by
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product prod = new Product();

				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				prod.setImage(rs.getString("image"));
				
				products.add(prod);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		
		return products;
	}

/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public Product getProductByTitle(String title) {
		
		Product prod = new Product();

		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT * FROM Products WHERE title = ?";	// Note the ? in the query
			stmt = connection.prepareStatement(sql);
			
			// This command populate the 1st '?' with the title and wildcards, between ' '
			stmt.setString(1, title);	
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {

				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				prod.setImage(rs.getString("image"));
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		
		return prod;
	}
	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public List<Product> getProductsByDescription(String description) {
		List<Product> products = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT * FROM Products WHERE description LIKE ?";
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, "%" + description + "%");
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product prod = new Product();

				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				prod.setImage(rs.getString("image"));
				
				products.add(prod);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		
		return products;
	}
	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public List<Product> getProductsByDescription(String description, String sorter) {
		
		//sorter is the field to sort by
		
		List<Product> products = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT * FROM Products WHERE description LIKE ? ORDER BY ?";
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, "%" + description + "%");
			stmt.setNString(2, sorter);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product prod = new Product();

				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				prod.setImage(rs.getString("image"));

				products.add(prod);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		
		return products;
	}
	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public List<Product> getProductsLessThanPrice(double price) {
		
		List<Product> products = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT * FROM Products WHERE price < ? ";
			stmt = connection.prepareStatement(sql);
			
			stmt.setDouble(1, price);
			
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product prod = new Product();

				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				prod.setImage(rs.getString("image"));
				
				products.add(prod);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		
		return products;
	}
	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public List<Product> getProductsLessThanPrice(double price, String sorter) {
		
		//sorter is the field to sort by
		
		List<Product> products = new ArrayList<>();

		try {
			connection = DAOUtilities.getConnection();
			String sql = "SELECT * FROM Products WHERE price < ? ORDER BY ?";
			stmt = connection.prepareStatement(sql);
			
			stmt.setDouble(1, price);
			stmt.setString(2, sorter);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product prod = new Product();

				prod.setTitle(rs.getString("title"));
				prod.setDescription(rs.getString("description"));
				prod.setPrice(rs.getDouble("price"));
				prod.setImage(rs.getString("image"));
				
				products.add(prod);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		
		return products;
	}

/*------------------------------------------------------------------------------------------------*/

	@Override
	public boolean addProduct(Product prod) {
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "INSERT INTO Products (title, description, price, image) VALUES (?, ?, ?, ?)";
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, prod.getTitle());
			stmt.setString(2, prod.getDescription());
			stmt.setDouble(3, prod.getPrice());
			stmt.setString(4, prod.getImage());
			
			if (stmt.executeUpdate() != 0)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			closeResources();
		}
	}
	
/*------------------------------------------------------------------------------------------------*/
	
	@Override
	public boolean updateProduct(Product prod) {
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "UPDATE Products SET description=?, price=?  WHERE title=?";
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, prod.getTitle());
			stmt.setString(2, prod.getDescription());
			stmt.setDouble(3, prod.getPrice());		
			System.out.println(stmt);
			
			if (stmt.executeUpdate() != 0)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			closeResources();
		}
		
	}
	
/*------------------------------------------------------------------------------------------------*/

	@Override
	public boolean deleteProductByTitle(String title) {
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "DELETE Products WHERE title=?";
			stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, title);

			if (stmt.executeUpdate() != 0)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			closeResources();
		}
	}

/*------------------------------------------------------------------------------------------------*/

	// Closing all resources
	private void closeResources() {
		try {
			if (stmt != null)
				stmt.close();
		} catch (SQLException e) {
			System.out.println("Could not close statement!");
			e.printStackTrace();
		}
		
		try {
			if (connection != null)
				connection.close();
		} catch (SQLException e) {
			System.out.println("Could not close connection!");
			e.printStackTrace();
		}
	}
}

	
	
/*-------------------------------------------------------------------------------------------------*/
	
